<form method="get" action="<?php bloginfo('url'); ?>/">
<input type="text" id="s" name="s" value="اكتب كلمات البحث هنا ..." onclick="if(this.value=='اكتب كلمات البحث هنا ...') this.value='';" onblur="if(this.value=='') this.value='اكتب كلمات البحث هنا ...';">
<input type="submit" value="">
</form>