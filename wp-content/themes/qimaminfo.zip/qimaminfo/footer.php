
<?php global $redux_demo; ?>

<footer class="footer">
   <div class="container">
	   <div class="row">
		   <div class="col-md-6 col-xs-12">
			   <div class=""><p>جميع الحقوق محفوظه لموقع قمم المعلومات</p></div>
		   </div>
		   <div class="col-md-6 col-xs-12">
			   <div class="socailmedia">
				   <ul class="list-inline">
					   <li>
						   <a href="<?php echo $redux_demo['twitter']; ?>" class="a1"><i class="fa fa-twitter"></i></a>
					   </li>
					   <li>
						   <a href="<?php echo $redux_demo['facebook']; ?>" class="a2"><i class="fa fa-facebook"></i></a>
					   </li>
					   <li>
						   <a href="<?php echo $redux_demo['google']; ?>" class="a3"><i class="fa fa-google-plus"></i></a>
					   </li>
					   <li>
						   <a href="<?php echo $redux_demo['instegram']; ?>" class="a4"><i class="fa fa-envelope-open-o"></i></a>
					   </li>
					   <li>
						   <a href="<?php echo $redux_demo['youtube']; ?>" class="a5"><i class="fa fa-rss"></i></a>
					   </li>
				   </ul>
			   </div>
		   </div>
	   </div>
   </div>
</footer>



		<?php wp_footer(); ?>

	</body>
</html>